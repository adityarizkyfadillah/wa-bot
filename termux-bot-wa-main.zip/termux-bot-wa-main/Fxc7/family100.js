[
{
    "result": {
        "Created": "Aditya Rizky Fadillah",
        "soal": "Apa yang menarik dari film india?",
        "jawaban": "Tarian\nLagu\nCerita\nPakian"
    }
},
{
    "result": {
        "Created": "Aditya Rizky Fadillah",
        "soal": "apa yang membuat pelayan di tempat fotokopi lambat?",
        "jawaban": "mesin rusak / rusak\nantri\nmati lampu\nkurang orang / kekurangan karyawan\nkertas habis\nmesin sedikit"
    }
},
{
    "result": {
        "Created": "Aditya Rizky Fadillah",
        "soal": "Jenis-jenis cewek yang didemenin para cowok?",
        "jawaban": "Cantik\nSeksi\nManis\nManja"
    }
},
{
    "result": {
        "Created": "Aditya Rizky Fadillah",
        "soal": "Sampah apa yang sering ditemukan dijalan?",
        "jawaban": "Kertas\nPlastik\nDaun\nPuntun\nRokok"
    }
},
{
    "result": {
        "Created": "Aditya Rizky Fadillah",
        "soal": "apa yang dilakukan orang kalau kecapean?",
        "jawaban": "tidur\nmakan\nminum\nistirahat\nspa\nmandi "
    }
},
{
    "result": {
        "Created": "Aditya Rizky Fadillah",
        "soal": "benda apa didalam rumah yang berwarna putih?",
        "jawaban": "lantai\ntembok\nlampu\nkulkas\nplastik\ntoples\nsofa / sofa putih"
    }
},
{
    "result": {
        "Created": "Aditya Rizky Fadillah",
        "soal": "sebutkan sesuatu yang memiliki tali?",
        "jawaban": "sepatu\npakaian dalam\ntas\ncelana\npulpen"
    }
},
{
    "result": {
        "Created": "Aditya Rizky Fadillah",
        "soal": "apa penyebab pinggang menjadi terkilir?",
        "jawaban": "angkat beban berat\nolahraga\njatuh\nsalah duduk "
    }
},
{
    "result": {
        "Created": "Aditya Rizky Fadillah",
        "soal": "bagian/part dari komputer umum?",
        "jawaban": "ram\ncpu\nmouse\nkeyboard\nmonitor\nprinter\nscanner"
    }
},
{
    "result": {
        "Created": "Aditya Rizky Fadillah",
        "soal": "suara yang ditakuti anak2?",
        "jawaban": "anjing\nhantu\npetir\nharimau"
    }
},
{
    "result": {
        "Created": "Aditya Rizky Fadillah",
        "soal": "Perasaan apa yang ada bila mau kencan pertama?",
        "jawaban": "\nSenang\nGrogi\nGembira\nDag dig dug"
    }
},
{
    "result": {
        "Created": "Aditya Rizky Fadillah",
        "soal": "selain kacang hijau, sebutkan ragam isi bakpau ?",
        "jawaban": "kacang hitam\ncoklat / cokelat\ndaging\nkentang "
    }
},
{
    "result": {
        "Created": "Aditya Rizky Fadillah",
        "soal": "sebutkan sesuatu yang sekali pakai langsung buang?",
        "jawaban": "pembalut\ntisu\npopok bayi / popok\nkorek api / korek\nteh celup\nkondom"
    }
},
{
    "result": {
        "Created": "Aditya Rizky Fadillah",
        "soal": "apa yang biasa dijadikan kado ulang tahun anak kecil?",
        "jawaban": "boneka\nsepeda\nkue\nbaju\ncelana\nmainan "
    }
},
{
    "result": {
        "Created": "Aditya Rizky Fadillah",
        "soal": "sebutkan sesuatu yang kamu beli dari uang jajan sendiri?",
        "jawaban": "makanan\nmainan\nminuman\nalat tulis "
    }
},
{
    "result": {
        "Created": "Aditya Rizky Fadillah",
        "soal": "bagian/part dari komputer umum?",
        "jawaban": "ram\ncpu\nmouse\nkeyboard\nmonitor\nprinter\nscanner"
    }
},
{
    "result": {
        "Created": "Aditya Rizky Fadillah",
        "soal": "alasan apa yang orang katakan untuk menyudahi pembicaran di telepon?",
        "jawaban": "baterai habis\nmau ke toilet\npulsa habis\nsibuk\ntelepon masuk\nmau istirahat\nada tamu "
    }
},
{
    "result": {
        "Created": "Aditya Rizky Fadillah",
        "soal": "gaya/ model berenang?",
        "jawaban": "punggung\ndada\nkupu-kupu\nkatak\nbebas "
    }
},
{
    "result": {
        "Created": "Aditya Rizky Fadillah",
        "soal": "Bekal makan anak sekolah?",
        "jawaban": "Mie\nNasi goreng\nRoti\nNasi uduk"
    }
},
{
    "result": {
        "Created": "Aditya Rizky Fadillah",
        "soal": "sebutkan warna-warna bunga mawar?",
        "jawaban": "merah\nputih\nkuning\njingga\norange\nmaroon\nmerah muda\nungu "
    }
},
{
    "result": {
        "Created": "Aditya Rizky Fadillah",
        "soal": "apa yang tidak perlu dimiliki orang yang botak?",
        "jawaban": "sisir\nsampo / shampo\ngel / minyak rambut\npengering rambut "
    }
},
{
    "result": {
        "Created": "Aditya Rizky Fadillah",
        "soal": "hal yang menakutkan bagi anak-anak?",
        "jawaban": "petir\nhantu\ngelap\norang marah / marah\nmimpi buruk / mimpi\npolisi"
    }
},
{
    "result": {
        "Created": "Aditya Rizky Fadillah",
        "soal": "Apa yang menyebabkan suara serak?",
        "jawaban": "Teriak\nBatuk\nNangis\nNgedem"
    }
},
{
    "result": {
        "Created": "Aditya Rizky Fadillah",
        "soal": "apa reaksi kamu jika mainan kamu tiba-tiba hidup?",
        "jawaban": "main bersama\ntakut\nsenang\nkaget\nbuang\nkasih tahu teman"
    }
},
{
    "result": {
        "Created": "Aditya Rizky Fadillah",
        "soal": "apa penyebab pinggang menjadi terkilir?",
        "jawaban": "angkat beban berat\nolahraga\njatuh\nsalah duduk "
    }
},
{
    "result": {
        "Created": "Aditya Rizky Fadillah",
        "soal": "apa yg biasanya sering lupa dibawa ?",
        "jawaban": "uang\ndompet\nhandphone\nkunci\nkacamata\nrokok\nstnk\nkorek"
    }
},
{
    "result": {
        "Created": "Aditya Rizky Fadillah",
        "soal": "hal yang menakutkan bagi anak-anak?",
        "jawaban": "petir\nhantu\ngelap\norang marah / marah\nmimpi buruk / mimpi\npolisi"
    }
},
{
    "result": {
        "Created": "Aditya Rizky Fadillah",
        "soal": "Jenis-jenis cewek yang didemenin para cowok?",
        "jawaban": "Cantik\nSeksi\nManis\nManja"
    }
},
{
    "result": {
        "Created": "Aditya Rizky Fadillah",
        "soal": "Sifat yang dimiliki anak-anak",
        "jawaban": "Manja\nCengeng\nNakal\nPemalu"
    }
},
{
    "result": {
        "Created": "Aditya Rizky Fadillah",
        "soal": "Apa yang dilakukan jika tersesat dihutan",
        "jawaban": "Menangis\nTeriak\nBerdoa\nDileme"
    }
},
{
    "result": {
        "Created": "Aditya Rizky Fadillah",
        "soal": "kota di usa?",
        "jawaban": "new york\nlos angeles\norlando\nlas vegas\ntexas\nseattle\nboston "
    }
},
{
    "result": {
        "Created": "Aditya Rizky Fadillah",
        "soal": "apa yang identik dengan bajaj?",
        "jawaban": "berisik / ribut\nroda tiga\noranye\nasap / polusi\nbergetar / getar\njakarta"
    }
},
{
    "result": {
        "Created": "Aditya Rizky Fadillah",
        "soal": "ditoko apa orang lebih sering  melihat-lihat daripada membeli?",
        "jawaban": "baju\nperhiasan / emas\nkendaraan\nbuku\nsepatu\nelektronik "
    }
},
{
    "result": {
        "Created": "Aditya Rizky Fadillah",
        "soal": "hewan tak berkaki?",
        "jawaban": "ular\ncacing\nbelut\nlintah\nsiput "
    }
},
{
    "result": {
        "Created": "Aditya Rizky Fadillah",
        "soal": "Sifat yang dimiliki anak-anak",
        "jawaban": "Manja\nCengeng\nNakal\nPemalu"
    }
}
]